from eliesi.core.engine import start_bot
from protect.obfuscate import check_license

check_license()
print("🚀 ELIESI ULTRA+ شروع شد…")

start_bot()
