#!/bin/bash
echo "🔥 اجرای ELIESI ULTRA+..."
python main.py
