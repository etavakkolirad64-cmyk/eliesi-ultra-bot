import hashlib, uuid, sys

def check_license():
    device = str(uuid.getnode())
    key = hashlib.sha256(device.encode()).hexdigest()

    try:
        with open("protect/eliesi_key.lic") as f:
            lic = f.read().strip()
    except:
        print("❌ فایل لایسنس پیدا نشد!")
        sys.exit()

    if lic != key:
        print("❌ لایسنس معتبر نیست!")
        sys.exit()
