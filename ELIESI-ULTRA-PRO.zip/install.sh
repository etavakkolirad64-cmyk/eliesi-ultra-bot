#!/bin/bash
echo "🚀 نصب ELIESI ULTRA+ شروع شد..."

pkg update -y
pkg upgrade -y
pkg install python -y

pip install --no-cache-dir numpy==1.26.0 pandas==1.5.3
pip install --no-cache-dir -r requirements_full.txt

echo ""
echo "✅ نصب کامل شد!"
echo "برای اجرای ربات دستور زیر را بزن:"
echo "./run.sh"
